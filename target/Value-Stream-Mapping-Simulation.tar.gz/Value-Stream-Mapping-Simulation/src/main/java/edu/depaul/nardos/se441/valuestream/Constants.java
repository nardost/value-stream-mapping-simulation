package edu.depaul.nardos.se441.valuestream;

public class Constants {
	public static final double MEAN_EXPECTATION = 3.5;
}
