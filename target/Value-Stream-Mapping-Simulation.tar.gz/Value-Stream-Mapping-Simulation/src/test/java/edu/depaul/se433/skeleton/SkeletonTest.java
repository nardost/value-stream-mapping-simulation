package edu.depaul.se433.skeleton;

import static org.junit.Assert.*;

import org.junit.Test;

public class SkeletonTest {

	@Test
	public void test() {
		assertTrue(true);
	}

}
