package edu.depaul.nardos.se441.valuestream;

import java.util.ArrayList;
import java.util.Iterator;
import org.javatuples.Sextet;

public class ValueStreamApp {
	public static void main(String [] args) {
		
		ValueStream valueStream = new ValueStream();

		int [] random1 = {4,5,1,5,3};
		int [] random2 = {5,6,5,3,1};
		int [] random3 = {6,3,6,2,1};
		int [] random4 = {3,1,4,5,6};
		int [] random5 = {6,4,1,4,4};
		
		valueStream.addStation(new Station("A"));
		valueStream.addStation(new Station("B"));
		valueStream.addStation(new Station("C"));
		valueStream.addStation(new Station("D"));
		valueStream.addStation(new Station("E"));

		valueStream.doCycle(random1);
		valueStream.doCycle(random2);
		valueStream.doCycle(random3);
		valueStream.doCycle(random4);
		valueStream.doCycle(random5);
		
		ArrayList<Sextet<String,Integer,Integer,Integer,Integer,Double>> state = valueStream.getState();
		Iterator<Sextet<String,Integer,Integer,Integer,Integer,Double>> iterator = state.iterator();
		while(iterator.hasNext()) {
			Sextet<String,Integer,Integer,Integer,Integer,Double> s = iterator.next();
			System.out.println("(" + s.getValue0() + ", " + s.getValue1() + ", " + s.getValue2() + ", " + s.getValue3() + ", " + s.getValue4() + ")");
		}
	}
}
